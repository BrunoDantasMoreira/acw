if __name__ == "__main__":
    print("See you in the next universe")
